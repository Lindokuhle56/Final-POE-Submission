﻿namespace CyberSecurityAwarenessBot.Models
{
    public class QuizQuestion
    {
        public string QuestionText { get; set; }
        public string[] Options { get; set; }
        public string CorrectAnswer { get; set; }
        public string Explanation { get; set; }
        public bool IsTrueFalse { get; set; }

        public QuizQuestion()
        {
            QuestionText = string.Empty;
            Options = new string[0];
            CorrectAnswer = string.Empty;
            Explanation = string.Empty;
        }
    }
}