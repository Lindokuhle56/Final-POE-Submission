﻿using System;

namespace CyberSecurityAwarenessBot.Models
{
    public class CyberTask
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime? ReminderDate { get; set; }
        public bool IsCompleted { get; set; }

        public CyberTask()
        {
            Title = string.Empty;
            Description = string.Empty;
        }

        public override string ToString()
        {
            string status = IsCompleted ? "[DONE]" : "[PENDING]";
            string reminder = ReminderDate.HasValue
                ? $" (Reminder: {ReminderDate.Value:dd MMM yyyy})"
                : "";
            return $"{status} {Title} - {Description}{reminder}";
        }
    }
}