﻿namespace CyberSecurityAwarenessBot
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            txtChat = new RichTextBox();
            txtInput = new TextBox();
            btnSend = new Button();
            SuspendLayout();
            // 
            // txtChat
            // 
            txtChat.Location = new Point(10, 10);
            txtChat.Name = "txtChat";
            txtChat.ReadOnly = true;
            txtChat.ScrollBars = RichTextBoxScrollBars.Vertical;
            txtChat.Size = new Size(846, 462);
            txtChat.TabIndex = 0;
            txtChat.Text = "";
            // 
            // txtInput
            // 
            txtInput.Location = new Point(10, 478);
            txtInput.Name = "txtInput";
            txtInput.Size = new Size(440, 27);
            txtInput.TabIndex = 1;
            txtInput.KeyPress += txtInput_KeyPress;
            // 
            // btnSend
            // 
            btnSend.Location = new Point(713, 492);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(110, 30);
            btnSend.TabIndex = 2;
            btnSend.Text = "Send";
            btnSend.Click += btnSend_Click;
            // 
            // Form1
            // 
            ClientSize = new Size(863, 543);
            Controls.Add(txtChat);
            Controls.Add(txtInput);
            Controls.Add(btnSend);
            Name = "Form1";
            Text = "Cybersecurity Awareness Chatbot";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.RichTextBox txtChat;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Button btnSend;
    }
}