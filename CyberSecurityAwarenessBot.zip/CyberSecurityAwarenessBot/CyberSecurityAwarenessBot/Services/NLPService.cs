﻿using System;
using System.Text.RegularExpressions;

namespace CyberSecurityAwarenessBot.Services
{
    public class NLPService
    {
        public enum Intent
        {
            AddTask,
            SetReminder,
            ViewTasks,
            DeleteTask,
            CompleteTask,
            StartQuiz,
            ShowLog,
            Greeting,
            CybersecurityInfo,
            Unknown
        }

        public Intent DetectIntent(string input)
        {
            string text = input.ToLower();

            if (text.Contains("add task") || text.Contains("create task") ||
                text.Contains("new task") || text.Contains("add a task") ||
                (text.Contains("task to") && text.Contains("add")))
                return Intent.AddTask;

            if (text.Contains("remind me") || text.Contains("set reminder") ||
                text.Contains("reminder") || text.Contains("remind"))
                return Intent.SetReminder;

            if (text.Contains("view task") || text.Contains("show task") ||
                text.Contains("my tasks") || text.Contains("list task"))
                return Intent.ViewTasks;

            if (text.Contains("delete task") || text.Contains("remove task"))
                return Intent.DeleteTask;

            if (text.Contains("complete") || text.Contains("mark task") ||
                text.Contains("finished task") || text.Contains("done with"))
                return Intent.CompleteTask;

            if (text.Contains("quiz") || text.Contains("test me") ||
                text.Contains("start game") || text.Contains("play"))
                return Intent.StartQuiz;

            if (text.Contains("activity log") || text.Contains("what have you done") ||
                text.Contains("show log") || text.Contains("recent actions"))
                return Intent.ShowLog;

            if (text.Contains("hello") || text.Contains("hi ") || text == "hi" ||
                text.Contains("hey") || text.Contains("good morning"))
                return Intent.Greeting;

            if (text.Contains("password") || text.Contains("phishing") ||
                text.Contains("malware") || text.Contains("privacy") ||
                text.Contains("scam") || text.Contains("virus"))
                return Intent.CybersecurityInfo;

            return Intent.Unknown;
        }

        public string ExtractTaskTitle(string input)
        {
            string text = input.ToLower();
            string[] triggers = { "add a task to", "add task to", "create task to", "task to", "add a task", "add task" };

            foreach (var trigger in triggers)
            {
                int index = text.IndexOf(trigger);
                if (index >= 0)
                {
                    string after = input.Substring(index + trigger.Length).Trim();
                    if (after.Length > 0)
                    {
                        return char.ToUpper(after[0]) + after.Substring(1);
                    }
                }
            }
            return "New Cybersecurity Task";
        }

        public int ExtractDays(string input)
        {
            string text = input.ToLower();

            Match match = Regex.Match(text, @"in (\d+) day");
            if (match.Success) return int.Parse(match.Groups[1].Value);

            match = Regex.Match(text, @"(\d+) day");
            if (match.Success) return int.Parse(match.Groups[1].Value);

            if (text.Contains("tomorrow")) return 1;
            if (text.Contains("next week")) return 7;

            return 0;
        }
    }
}