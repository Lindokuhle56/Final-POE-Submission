﻿using System;
using System.Collections.Generic;
using CyberSecurityAwarenessBot.Models;

namespace CyberSecurityAwarenessBot.Services
{
    public class QuizService
    {
        private readonly List<QuizQuestion> questions;
        private int currentIndex;
        private int score;

        public QuizService()
        {
            score = 0;
            currentIndex = 0;
            questions = new List<QuizQuestion>
            {
                new QuizQuestion {
                    QuestionText = "What should you do if you receive an email asking for your password?",
                    Options = new[] { "A) Reply with your password", "B) Delete the email", "C) Report the email as phishing", "D) Ignore it" },
                    CorrectAnswer = "C",
                    Explanation = "Reporting phishing emails helps prevent scams and protects others.",
                    IsTrueFalse = false
                },
                new QuizQuestion {
                    QuestionText = "True or False: You should use the same password for all your accounts.",
                    CorrectAnswer = "False",
                    Explanation = "Reusing passwords means one breach can expose ALL your accounts.",
                    IsTrueFalse = true
                },
                new QuizQuestion {
                    QuestionText = "What does '2FA' stand for?",
                    Options = new[] { "A) Two-Factor Authentication", "B) Two-File Access", "C) Trusted Firewall Access", "D) Two-Form Authorisation" },
                    CorrectAnswer = "A",
                    Explanation = "2FA adds a second layer of security beyond just your password.",
                    IsTrueFalse = false
                },
                new QuizQuestion {
                    QuestionText = "True or False: Public Wi-Fi is always safe to use for online banking.",
                    CorrectAnswer = "False",
                    Explanation = "Public Wi-Fi can be monitored by attackers - use a VPN or mobile data instead.",
                    IsTrueFalse = true
                },
                new QuizQuestion {
                    QuestionText = "Which of the following is the strongest password?",
                    Options = new[] { "A) password123", "B) John1990", "C) !Kx7#mP2$qL", "D) abc123" },
                    CorrectAnswer = "C",
                    Explanation = "Strong passwords mix uppercase, lowercase, numbers, and symbols.",
                    IsTrueFalse = false
                },
                new QuizQuestion {
                    QuestionText = "What is 'phishing'?",
                    Options = new[] { "A) A type of malware", "B) A trick to steal your info via fake emails/messages", "C) A firewall setting", "D) A safe browsing tool" },
                    CorrectAnswer = "B",
                    Explanation = "Phishing tricks users into handing over personal information.",
                    IsTrueFalse = false
                },
                new QuizQuestion {
                    QuestionText = "True or False: Antivirus software alone is enough to stay fully safe online.",
                    CorrectAnswer = "False",
                    Explanation = "You also need safe habits, regular updates, and strong passwords.",
                    IsTrueFalse = true
                },
                new QuizQuestion {
                    QuestionText = "What should you do before clicking a link in an unexpected email?",
                    Options = new[] { "A) Click it immediately", "B) Hover over it to check the real URL", "C) Forward it to friends", "D) Reply asking if it's safe" },
                    CorrectAnswer = "B",
                    Explanation = "Hovering reveals the real destination before you click anything.",
                    IsTrueFalse = false
                },
                new QuizQuestion {
                    QuestionText = "True or False: Software updates often contain important security patches.",
                    CorrectAnswer = "True",
                    Explanation = "Updates regularly fix vulnerabilities that attackers could otherwise exploit.",
                    IsTrueFalse = true
                },
                new QuizQuestion {
                    QuestionText = "What is 'social engineering' in cybersecurity?",
                    Options = new[] { "A) Building social media apps", "B) Manipulating people to reveal confidential info", "C) Network engineering", "D) Programming chat bots" },
                    CorrectAnswer = "B",
                    Explanation = "Social engineering exploits human trust rather than technical weaknesses.",
                    IsTrueFalse = false
                },
                new QuizQuestion {
                    QuestionText = "True or False: A padlock icon (HTTPS) means a website is 100% trustworthy.",
                    CorrectAnswer = "False",
                    Explanation = "HTTPS only means the connection is encrypted - the site itself can still be a scam.",
                    IsTrueFalse = true
                }
            };
        }

        public bool IsFinished()
        {
            return currentIndex >= questions.Count;
        }

        public QuizQuestion GetCurrentQuestion()
        {
            return IsFinished() ? null : questions[currentIndex];
        }

        public bool SubmitAnswer(string userAnswer)
        {
            if (IsFinished()) return false;

            bool isCorrect = string.Equals(
                userAnswer.Trim(),
                questions[currentIndex].CorrectAnswer.Trim(),
                StringComparison.OrdinalIgnoreCase);

            if (isCorrect) score++;
            currentIndex++;
            return isCorrect;
        }

        public int GetScore() => score;
        public int TotalQuestions() => questions.Count;
        public int QuestionsAnswered() => currentIndex;

        public void Reset()
        {
            currentIndex = 0;
            score = 0;
        }

        public string GetFinalFeedback()
        {
            double percent = (double)score / questions.Count * 100;
            if (percent >= 80) return "Great job! You're a cybersecurity pro!";
            if (percent >= 50) return "Good effort! Keep learning to stay safe online.";
            return "Keep learning - cybersecurity knowledge protects you every day!";
        }
    }
}