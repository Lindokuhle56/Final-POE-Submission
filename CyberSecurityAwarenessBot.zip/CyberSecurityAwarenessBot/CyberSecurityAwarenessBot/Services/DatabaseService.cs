﻿using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using CyberSecurityAwarenessBot.Models;

namespace CyberSecurityAwarenessBot.Services
{
    public class DatabaseService
    {
        private readonly string connectionString =
            "Server=localhost;Database=chatbot_db;Uid=root;Pwd=CyberBot@2026;";

        public void InitializeDatabase()
        {
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string createTable = @"
                    CREATE TABLE IF NOT EXISTS Tasks (
                        Id INT AUTO_INCREMENT PRIMARY KEY,
                        Title VARCHAR(255) NOT NULL,
                        Description TEXT,
                        ReminderDate DATETIME NULL,
                        IsCompleted BOOLEAN DEFAULT FALSE,
                        CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
                    );";
                using (var cmd = new MySqlCommand(createTable, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void AddTask(string title, string description, DateTime? reminder)
        {
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string insert = "INSERT INTO Tasks (Title, Description, ReminderDate) " +
                                 "VALUES (@title, @desc, @reminder);";
                using (var cmd = new MySqlCommand(insert, conn))
                {
                    cmd.Parameters.AddWithValue("@title", title);
                    cmd.Parameters.AddWithValue("@desc", description);
                    cmd.Parameters.AddWithValue("@reminder", (object)reminder ?? DBNull.Value);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public List<CyberTask> GetAllTasks()
        {
            var tasks = new List<CyberTask>();
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string select = "SELECT * FROM Tasks ORDER BY CreatedAt DESC;";
                using (var cmd = new MySqlCommand(select, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        tasks.Add(new CyberTask
                        {
                            Id = reader.GetInt32("Id"),
                            Title = reader.GetString("Title"),
                            Description = reader.IsDBNull(reader.GetOrdinal("Description"))
                                ? "" : reader.GetString("Description"),
                            ReminderDate = reader.IsDBNull(reader.GetOrdinal("ReminderDate"))
                                ? (DateTime?)null : reader.GetDateTime("ReminderDate"),
                            IsCompleted = reader.GetBoolean("IsCompleted")
                        });
                    }
                }
            }
            return tasks;
        }

        public void MarkCompleted(int id)
        {
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string update = "UPDATE Tasks SET IsCompleted = TRUE WHERE Id = @id;";
                using (var cmd = new MySqlCommand(update, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void DeleteTask(int id)
        {
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string delete = "DELETE FROM Tasks WHERE Id = @id;";
                using (var cmd = new MySqlCommand(delete, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}