﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CyberSecurityAwarenessBot.Services
{
    public class ActivityLogService
    {
        private readonly List<string> log = new List<string>();
        private const int MaxVisible = 10;

        public void AddEntry(string description)
        {
            string entry = $"[{DateTime.Now:yyyy-MM-dd HH:mm}] {description}";
            log.Add(entry);
        }

        public List<string> GetRecentEntries()
        {
            int start = Math.Max(0, log.Count - MaxVisible);
            return log.GetRange(start, log.Count - start);
        }

        public List<string> GetFullHistory()
        {
            return new List<string>(log);
        }

        public string GetFormattedLog()
        {
            var recent = GetRecentEntries();
            if (recent.Count == 0)
                return "No actions recorded yet.";

            var sb = new StringBuilder();
            sb.AppendLine("Here's a summary of recent actions:");
            sb.AppendLine();
            for (int i = 0; i < recent.Count; i++)
            {
                sb.AppendLine($"{i + 1}. {recent[i]}");
            }
            return sb.ToString();
        }
    }
}