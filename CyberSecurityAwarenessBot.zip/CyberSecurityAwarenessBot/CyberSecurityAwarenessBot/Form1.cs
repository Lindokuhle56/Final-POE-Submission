using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Media;

namespace CyberSecurityAwarenessBot
{
    public partial class Form1 : Form
    {
        // Memory
        private string userName = "";
        private string userInterest = "";
        private string lastTopic = "";
        private Random random = new Random();

        // Tips Lists
        private List<string> passwordTips = new List<string>()
        {
            "Use at least 12 characters with letters, numbers and symbols!",
            "Never use your birthday or name as a password!",
            "Use a different password for every website!",
            "Consider using a password manager like LastPass!",
            "Never share your password with anyone!"
        };

        private List<string> phishingTips = new List<string>()
        {
            "Be cautious of emails asking for personal information!",
            "Always check the senders email address carefully!",
            "Never click suspicious links in emails!",
            "Banks will NEVER ask for your password via email!"
        };

        private List<string> scamTips = new List<string>()
        {
            "Scammers often pretend to be from SARS or your bank!",
            "Never send money to someone you met online!",
            "If someone asks for gift cards as payment its a scam!",
            "Always verify by calling the company directly!"
        };

        private List<string> privacyTips = new List<string>()
        {
            "Check your Facebook privacy settings regularly!",
            "Dont share your ID number or address online!",
            "Use a VPN when on public WiFi!",
            "Turn off location sharing when you dont need it!"
        };

        private List<string> malwareTips = new List<string>()
        {
            "Always keep your antivirus updated!",
            "Dont download apps from unknown websites!",
            "Scan USB drives before opening files on them!",
            "Keep Windows updated to patch security holes!"
        };

        public Form1()
        {
            InitializeComponent();
            StyleControls();
            ShowWelcome();
            VoiceGreeting();
        }

        private void StyleControls()
        {
            // Form background
            this.BackColor = Color.FromArgb(20, 20, 50);
            this.Text = "Cybersecurity Awareness Chatbot";

            // Chat box styling
            txtChat.BackColor = Color.FromArgb(15, 15, 40);
            txtChat.ForeColor = Color.LightGreen;
            txtChat.Font = new Font("Consolas", 10);

            // Input box styling
            txtInput.BackColor = Color.FromArgb(40, 40, 80);
            txtInput.ForeColor = Color.White;
            txtInput.Font = new Font("Consolas", 10);

            // Button styling
            btnSend.BackColor = Color.FromArgb(0, 120, 215);
            btnSend.ForeColor = Color.White;
            btnSend.Font = new Font("Consolas", 10, FontStyle.Bold);
            btnSend.FlatStyle = FlatStyle.Flat;
        }

        private void ShowWelcome()
        {
            // ASCII Art
            txtChat.AppendText("  ██████╗██╗   ██╗██████╗ ███████╗██████╗ \n");
            txtChat.AppendText(" ██╔════╝╚██╗ ██╔╝██╔══██╗██╔════╝██╔══██╗\n");
            txtChat.AppendText(" ██║      ╚████╔╝ ██████╔╝█████╗  ██████╔╝\n");
            txtChat.AppendText(" ██║       ╚██╔╝  ██╔══██╗██╔══╝  ██╔══██╗\n");
            txtChat.AppendText(" ╚██████╗   ██║   ██████╔╝███████╗██║  ██║\n");
            txtChat.AppendText("  ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝\n");
            txtChat.AppendText("\n");
            txtChat.AppendText("╔══════════════════════════════════════╗\n");
            txtChat.AppendText("║   🔒 CYBERSECURITY AWARENESS BOT 🔒  ║\n");
            txtChat.AppendText("║   Keeping You Safe Online!           ║\n");
            txtChat.AppendText("╚══════════════════════════════════════╝\n");
            txtChat.AppendText("\n");
            txtChat.AppendText("Bot: Hello! I am your Cybersecurity Assistant!\n");
            txtChat.AppendText("Bot: I can help with passwords, phishing,\n");
            txtChat.AppendText("     scams, privacy and malware!\n\n");
            txtChat.AppendText("Bot: What is your name?\n\n");
        }

        private void VoiceGreeting()
        {
            try
            {
                voice.Volume = 100;
                voice.Rate = 0;
                voice.SpeakAsync(
                    "Welcome to the Cybersecurity Awareness Chatbot. " +
                    "I am here to help keep you safe online. " +
                    "Please tell me your name to get started.");
            }
            catch { }
        }

       
        

        private void btnSend_Click(object sender, EventArgs e)
        {
            string userMessage = txtInput.Text.Trim();
            if (userMessage == "") return;

            txtChat.SelectionColor = Color.Cyan;
            txtChat.AppendText("You: " + userMessage + "\n");

            string reply = GetReply(userMessage);

            txtChat.SelectionColor = Color.LightGreen;
            txtChat.AppendText("Bot: " + reply + "\n\n");

            BotSpeak(reply);
            txtInput.Clear();
            txtChat.ScrollToCaret();
        }

        private string GetReply(string message)
        {
            string msg = message.ToLower();

            if (msg.Contains("my name is"))
            {
                userName = message.Substring(
                    message.ToLower().IndexOf("my name is") + 10).Trim();
                return "Nice to meet you " + userName +
                       "! How can I help you stay safe online?";
            }

            if (msg.Contains("i'm interested in") ||
                msg.Contains("i am interested in"))
            {
                userInterest = msg.Contains("i'm interested in")
                    ? message.Substring(
                        msg.IndexOf("i'm interested in") + 17).Trim()
                    : message.Substring(
                        msg.IndexOf("i am interested in") + 18).Trim();
                return "Great! I will remember you are interested in "
                       + userInterest + "!";
            }

            if (msg.Contains("tell me more") ||
                msg.Contains("another tip") ||
                msg.Contains("explain more") ||
                msg.Contains("give me more"))
            {
                if (lastTopic == "password") return GetRandomTip(passwordTips);
                if (lastTopic == "phishing") return GetRandomTip(phishingTips);
                if (lastTopic == "scam") return GetRandomTip(scamTips);
                if (lastTopic == "privacy") return GetRandomTip(privacyTips);
                if (lastTopic == "malware") return GetRandomTip(malwareTips);
                return "What topic do you want more info about?";
            }

            if (msg.Contains("worried") || msg.Contains("scared"))
                return "It is understandable to feel that way! " +
                       "Would you like some safety tips?";

            if (msg.Contains("frustrated") || msg.Contains("confused"))
                return "Lets take it one step at a time. " +
                       "What are you struggling with?";

            if (msg.Contains("curious"))
                return "Great curiosity! What would you like to learn about?";

            if (msg.Contains("password"))
            {
                lastTopic = "password";
                return GetRandomTip(passwordTips);
            }

            if (msg.Contains("phishing") || msg.Contains("fake email"))
            {
                lastTopic = "phishing";
                return GetRandomTip(phishingTips);
            }

            if (msg.Contains("scam") || msg.Contains("fraud"))
            {
                lastTopic = "scam";
                return GetRandomTip(scamTips);
            }

            if (msg.Contains("privacy") || msg.Contains("private"))
            {
                lastTopic = "privacy";
                return GetRandomTip(privacyTips);
            }

            if (msg.Contains("malware") || msg.Contains("virus"))
            {
                lastTopic = "malware";
                return GetRandomTip(malwareTips);
            }

            if (msg.Contains("hello") || msg.Contains("hi") ||
                msg.Contains("hey"))
                return userName != ""
                    ? "Hello again " + userName + "! How can I help?"
                    : "Hello! What is your name?";

            if (msg.Contains("tip") || msg.Contains("help"))
                return userInterest != ""
                    ? "Since you are interested in " + userInterest +
                      ", always stay updated on threats!"
                    : "I can help with: passwords, phishing, " +
                      "scams, privacy or malware!";

            return "I am not sure I understand. Try asking about: " +
                   "passwords, phishing, scams, privacy or malware!";
        }

        private string GetRandomTip(List<string> tips)
        {
            return tips[random.Next(tips.Count)];
        }

        private void txtInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
                btnSend_Click(sender, e);
        }
