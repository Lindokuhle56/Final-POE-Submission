# CyberSecurity Awareness Chatbot

## Project Overview
The CyberSecurity Awareness Chatbot is a Windows Forms application developed in C# using Visual Studio Community. 

The purpose of this application is to educate users about cybersecurity awareness through an interactive chatbot interface. The chatbot provides information and safety tips about important cybersecurity topics such as passwords, phishing, scams, and privacy.

This project was developed as part of the PROG6221 Portfolio of Evidence (POE).

---

# Features

## GUI Interface
- Developed using Windows Forms
- User-friendly interface
- Interactive chatbot conversation area
- Input textbox and send button
- Clean layout and colour design

## Cybersecurity Topics
The chatbot recognises cybersecurity-related keywords including:
- Password safety
- Phishing
- Online scams
- Privacy and online protection

## Random Responses
The chatbot uses random responses for certain topics to make conversations feel more natural and less repetitive.

## Conversation Flow
The chatbot can continue conversations using prompts such as:
- "Tell me more"
- "Explain more"
- "Give me another tip"

## Memory and Recall
The chatbot remembers certain user information such as:
- User name
- Favourite cybersecurity topic

This allows the chatbot to personalise responses.

## Sentiment Detection
The chatbot detects simple emotions such as:
- Worried
- Curious
- Frustrated

The chatbot then adjusts its responses to provide support and guidance.

## Error Handling
The chatbot handles unknown inputs gracefully by displaying a default response instead of crashing.

## Welcome Audio
The application includes a welcome audio greeting that plays when the chatbot starts.
# Technologies Used
- C#
- Windows Forms
- .NET Framework
- Visual Studio Community 2026

# How to Run the Project

1. Open the solution file in Visual Studio Community.
2. Build the project.
3. Press F5 or click the Start button.
4. The chatbot application will launch.

# Project Structure

## Main Files
- Form1.cs → Main chatbot logic
- Form1.Designer.cs → GUI design
- Program.cs → Application entry point
- welcome.wav → Audio greeting file

# Example User Inputs
- "Tell me about password safety"
- "Give me a phishing tip"
- "I am worried about scams"
- "Tell me more"
- "What do you remember about me?"

# Future Improvements
- More cybersecurity topics
- Advanced AI responses
- Database integration
- Improved sentiment analysis
- User login system


# Author
Lindokuhle Maila
