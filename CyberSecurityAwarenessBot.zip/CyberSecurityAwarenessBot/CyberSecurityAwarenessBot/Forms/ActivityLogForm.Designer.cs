﻿namespace CyberSecurityAwarenessBot.Forms
{
    partial class ActivityLogForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private System.Windows.Forms.TextBox txtLog;

        private void InitializeComponent()
        {
            this.txtLog = new System.Windows.Forms.TextBox();

            this.Text = "Activity Log";
            this.ClientSize = new System.Drawing.Size(480, 360);

            this.txtLog.Multiline = true;
            this.txtLog.ReadOnly = true;
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLog.Left = 20;
            this.txtLog.Top = 20;
            this.txtLog.Width = 440;
            this.txtLog.Height = 320;

            this.Controls.Add(this.txtLog);
        }
    }
}