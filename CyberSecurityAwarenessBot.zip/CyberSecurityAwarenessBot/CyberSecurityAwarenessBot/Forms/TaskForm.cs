﻿using System;
using System.Windows.Forms;
using CyberSecurityAwarenessBot.Services;

namespace CyberSecurityAwarenessBot.Forms
{
    public partial class TaskForm : Form
    {
        private readonly DatabaseService dbService;
        private readonly ActivityLogService activityLog;

        public TaskForm(DatabaseService database, ActivityLogService log)
        {
            dbService = database;
            activityLog = log;
            InitializeComponent();
            LoadTasks();
        }

        private void LoadTasks()
        {
            lstTasks.Items.Clear();
            var tasks = dbService.GetAllTasks();
            foreach (var task in tasks)
            {
                lstTasks.Items.Add(task);
            }
        }

        private void BtnAddTask_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Please enter a task title.");
                return;
            }

            DateTime? reminder = chkUseReminder.Checked ? dtpReminder.Value : (DateTime?)null;

            dbService.AddTask(txtTitle.Text, txtDescription.Text, reminder);

            string reminderText = reminder.HasValue
                ? $" (Reminder set for {reminder.Value:dd MMM yyyy})"
                : " (no reminder set)";
            activityLog.AddEntry($"Task added: '{txtTitle.Text}'{reminderText}");

            txtTitle.Clear();
            txtDescription.Clear();
            chkUseReminder.Checked = false;
            LoadTasks();
        }

        private void BtnMarkComplete_Click(object sender, EventArgs e)
        {
            if (lstTasks.SelectedItem == null)
            {
                MessageBox.Show("Please select a task first.");
                return;
            }

            var tasks = dbService.GetAllTasks();
            int selectedIndex = lstTasks.SelectedIndex;
            var selectedTask = tasks[selectedIndex];

            dbService.MarkCompleted(selectedTask.Id);
            activityLog.AddEntry($"Task marked as completed: '{selectedTask.Title}'");
            LoadTasks();
        }

        private void BtnDeleteTask_Click(object sender, EventArgs e)
        {
            if (lstTasks.SelectedItem == null)
            {
                MessageBox.Show("Please select a task first.");
                return;
            }

            var tasks = dbService.GetAllTasks();
            int selectedIndex = lstTasks.SelectedIndex;
            var selectedTask = tasks[selectedIndex];

            dbService.DeleteTask(selectedTask.Id);
            activityLog.AddEntry($"Task deleted: '{selectedTask.Title}'");
            LoadTasks();
        }
    }
}