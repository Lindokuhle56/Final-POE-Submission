﻿using CyberSecurityAwarenessBot.Services;

namespace CyberSecurityAwarenessBot.Forms
{
    public partial class ActivityLogForm : Form
    {
        public ActivityLogForm(ActivityLogService activityLog)
        {
            InitializeComponent();
            txtLog.Text = activityLog.GetFormattedLog();
        }
    }
}