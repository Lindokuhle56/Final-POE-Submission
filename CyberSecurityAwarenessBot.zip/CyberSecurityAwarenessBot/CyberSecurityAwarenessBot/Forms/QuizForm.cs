﻿using System;
using System.Windows.Forms;
using CyberSecurityAwarenessBot.Services;

namespace CyberSecurityAwarenessBot.Forms
{
    public partial class QuizForm : Form
    {
        private readonly QuizService quizService;
        private readonly ActivityLogService activityLog;

        public QuizForm(QuizService quiz, ActivityLogService log)
        {
            quizService = quiz;
            activityLog = log;
            InitializeComponent();
            activityLog.AddEntry("Quiz started.");
            ShowCurrentQuestion();
        }

        private void ShowCurrentQuestion()
        {
            if (quizService.IsFinished())
            {
                ShowFinalResults();
                return;
            }

            var question = quizService.GetCurrentQuestion();
            lblQuestion.Text = question.QuestionText;
            lblFeedback.Text = "";

            if (question.IsTrueFalse)
            {
                optA.Text = "True";
                optB.Text = "False";
                optC.Visible = false;
                optD.Visible = false;
            }
            else
            {
                optA.Text = question.Options[0];
                optB.Text = question.Options[1];
                optC.Text = question.Options[2];
                optC.Visible = true;
                optD.Text = question.Options[3];
                optD.Visible = true;
            }

            optA.Checked = false;
            optB.Checked = false;
            optC.Checked = false;
            optD.Checked = false;
        }

        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            string userAnswer = GetSelectedAnswer();
            if (userAnswer == null)
            {
                MessageBox.Show("Please select an answer.");
                return;
            }

            var question = quizService.GetCurrentQuestion();
            bool correct = quizService.SubmitAnswer(userAnswer);

            lblFeedback.Text = (correct ? "Correct! " : "Incorrect. ") + question.Explanation;
            lblScore.Text = $"Score: {quizService.GetScore()}/{quizService.QuestionsAnswered()}";

            System.Windows.Forms.Timer delay = new System.Windows.Forms.Timer();
            delay.Interval = 2000;
            delay.Tick += (s, args) =>
            {
                delay.Stop();
                ShowCurrentQuestion();
            };
            delay.Start();
        }

        private string GetSelectedAnswer()
        {
            var question = quizService.GetCurrentQuestion();
            if (question.IsTrueFalse)
            {
                if (optA.Checked) return "True";
                if (optB.Checked) return "False";
                return null;
            }
            else
            {
                if (optA.Checked) return "A";
                if (optB.Checked) return "B";
                if (optC.Checked) return "C";
                if (optD.Checked) return "D";
                return null;
            }
        }

        private void ShowFinalResults()
        {
            lblQuestion.Text = "Quiz Complete!";
            lblFeedback.Text = quizService.GetFinalFeedback();
            lblScore.Text = $"Final Score: {quizService.GetScore()}/{quizService.TotalQuestions()}";

            optA.Visible = false;
            optB.Visible = false;
            optC.Visible = false;
            optD.Visible = false;
            btnSubmit.Visible = false;

            activityLog.AddEntry($"Quiz completed - Score: {quizService.GetScore()}/{quizService.TotalQuestions()}");
        }
    }
}