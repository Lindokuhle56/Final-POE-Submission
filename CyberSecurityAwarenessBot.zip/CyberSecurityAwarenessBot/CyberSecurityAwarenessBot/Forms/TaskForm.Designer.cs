﻿namespace CyberSecurityAwarenessBot.Forms
{
    partial class TaskForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private TextBox txtTitle;
        private TextBox txtDescription;
        private DateTimePicker dtpReminder;
        private CheckBox chkUseReminder;
        private Button btnAddTask;
        private Button btnMarkComplete;
        private Button btnDeleteTask;
        private ListBox lstTasks;
        private Label lblTitle;
        private Label lblDesc;

        private void InitializeComponent()
        {
            this.lblTitle = new Label();
            this.txtTitle = new TextBox();
            this.lblDesc = new Label();
            this.txtDescription = new TextBox();
            this.chkUseReminder = new CheckBox();
            this.dtpReminder = new DateTimePicker();
            this.btnAddTask = new Button();
            this.lstTasks = new ListBox();
            this.btnMarkComplete = new Button();
            this.btnDeleteTask = new Button();

            this.Text = "Task Assistant - Cybersecurity Chatbot";
            this.ClientSize = new System.Drawing.Size(480, 480);

            this.lblTitle.Text = "Task Title:";
            this.lblTitle.Left = 20;
            this.lblTitle.Top = 20;
            this.lblTitle.Width = 100;

            this.txtTitle.Left = 130;
            this.txtTitle.Top = 18;
            this.txtTitle.Width = 320;

            this.lblDesc.Text = "Description:";
            this.lblDesc.Left = 20;
            this.lblDesc.Top = 55;
            this.lblDesc.Width = 100;

            this.txtDescription.Left = 130;
            this.txtDescription.Top = 53;
            this.txtDescription.Width = 320;
            this.txtDescription.Height = 60;
            this.txtDescription.Multiline = true;

            this.chkUseReminder.Text = "Set Reminder";
            this.chkUseReminder.Left = 130;
            this.chkUseReminder.Top = 125;
            this.chkUseReminder.Width = 150;

            this.dtpReminder.Left = 130;
            this.dtpReminder.Top = 150;
            this.dtpReminder.Width = 200;

            this.btnAddTask.Text = "Add Task";
            this.btnAddTask.Left = 130;
            this.btnAddTask.Top = 185;
            this.btnAddTask.Width = 100;
            this.btnAddTask.Click += new System.EventHandler(this.BtnAddTask_Click);

            this.lstTasks.Left = 20;
            this.lstTasks.Top = 225;
            this.lstTasks.Width = 430;
            this.lstTasks.Height = 180;

            this.btnMarkComplete.Text = "Mark Complete";
            this.btnMarkComplete.Left = 20;
            this.btnMarkComplete.Top = 415;
            this.btnMarkComplete.Width = 130;
            this.btnMarkComplete.Click += new System.EventHandler(this.BtnMarkComplete_Click);

            this.btnDeleteTask.Text = "Delete Task";
            this.btnDeleteTask.Left = 160;
            this.btnDeleteTask.Top = 415;
            this.btnDeleteTask.Width = 130;
            this.btnDeleteTask.Click += new System.EventHandler(this.BtnDeleteTask_Click);

            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.lblDesc);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.chkUseReminder);
            this.Controls.Add(this.dtpReminder);
            this.Controls.Add(this.btnAddTask);
            this.Controls.Add(this.lstTasks);
            this.Controls.Add(this.btnMarkComplete);
            this.Controls.Add(this.btnDeleteTask);
        }
    }
}