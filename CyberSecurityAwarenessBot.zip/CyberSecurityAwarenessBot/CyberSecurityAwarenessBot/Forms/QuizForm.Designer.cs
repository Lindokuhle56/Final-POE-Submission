﻿namespace CyberSecurityAwarenessBot.Forms
{
    partial class QuizForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private Label lblQuestion;
        private RadioButton optA;
        private RadioButton optB;
        private RadioButton optC;
        private RadioButton optD;
        private Button btnSubmit;
        private Label lblFeedback;
        private Label lblScore;

        private void InitializeComponent()
        {
            this.lblQuestion = new Label();
            this.optA = new RadioButton();
            this.optB = new RadioButton();
            this.optC = new RadioButton();
            this.optD = new RadioButton();
            this.btnSubmit = new Button();
            this.lblFeedback = new Label();
            this.lblScore = new Label();

            this.Text = "Cybersecurity Quiz";
            this.ClientSize = new System.Drawing.Size(480, 360);

            this.lblQuestion.Left = 20;
            this.lblQuestion.Top = 20;
            this.lblQuestion.Width = 440;
            this.lblQuestion.Height = 60;
            this.lblQuestion.Font = new System.Drawing.Font("Arial", 11);

            this.optA.Left = 20;
            this.optA.Top = 90;
            this.optA.Width = 440;

            this.optB.Left = 20;
            this.optB.Top = 120;
            this.optB.Width = 440;

            this.optC.Left = 20;
            this.optC.Top = 150;
            this.optC.Width = 440;

            this.optD.Left = 20;
            this.optD.Top = 180;
            this.optD.Width = 440;

            this.btnSubmit.Text = "Submit Answer";
            this.btnSubmit.Left = 20;
            this.btnSubmit.Top = 220;
            this.btnSubmit.Width = 150;
            this.btnSubmit.Click += new System.EventHandler(this.BtnSubmit_Click);

            this.lblFeedback.Left = 20;
            this.lblFeedback.Top = 260;
            this.lblFeedback.Width = 440;
            this.lblFeedback.Height = 60;
            this.lblFeedback.ForeColor = System.Drawing.Color.DarkBlue;

            this.lblScore.Left = 20;
            this.lblScore.Top = 330;
            this.lblScore.Width = 300;

            this.Controls.Add(this.lblQuestion);
            this.Controls.Add(this.optA);
            this.Controls.Add(this.optB);
            this.Controls.Add(this.optC);
            this.Controls.Add(this.optD);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.lblFeedback);
            this.Controls.Add(this.lblScore);
        }
    }
}